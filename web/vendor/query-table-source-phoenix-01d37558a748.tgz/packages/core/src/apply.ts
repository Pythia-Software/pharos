import { aggOpsForField, isMeasurable } from "./agg";
import type { MetricKey } from "./metricTypes";
import { evaluateMetrics, type MetricEvaluationOptions } from "./metrics";
// apply.ts — client-side filter + multi-sort + paginate.
//
// applyQuery is the client mirror of the backend compiler. Three jobs:
//   1. The executor for purely client-side datasets (no backend at all).
//   2. The executor for derived / non-pushdown columns the backend can't filter.
//   3. Idempotent defense-in-depth over server-filtered fields (re-applying a
//      server-handled clause must not change the result).
//
// It must agree with backends/go's Compile on operator semantics:
//   - `contains`/`starts_with`/`ends_with` are case-insensitive
//   - textarray `is_null` = empty-or-missing; `is_not_null` = any element;
//     `includes` = case-insensitive membership
//   - NULLs sort per OrderByClause.nulls (default "last")
//   - multi-sort is a stable lexicographic fold over orderBy in priority order

import { evaluationTime, type QueryEvaluationOptions } from "./relativeTime";
import { isComputedField } from "./computed";
import type {
  AggOp,
  AggregationClause,
  QueryState,
  WhereClause,
  WhereTerm,
} from "./query";
import type { FieldSchema, FieldDef } from "./schema";
import type { AggregationBucket, AggregationResult } from "./encode";
import { indexFields, readFieldValue, resolveFieldName } from "./schema";
import { isOrGroup, predicatesOf, normalizeQueryState } from "./query";
import { coerceValue } from "./ops";
import { prepareGrouping, withoutGrouping } from "./grouping";

export interface ApplyResult<Row> {
  /** The page slice (after filter + sort + offset/limit). */
  rows: Row[];
  /** Total matching rows *before* pagination — powers "showing N of M". */
  total: number;
}

/** Filter + multi-sort + paginate `rows` per `q`, resolving field types/paths
 *  from `schema`. Never mutates `rows`. Relative predicates use options.now or
 *  one captured Date.now(). Clauses/sorts on unknown fields are
 *  ignored (the backend already enforced its own allowlist). */
export function applyQuery<Row>(
  rows: Row[],
  q: QueryState,
  schema: FieldSchema<Row>,
  options: QueryEvaluationOptions = {},
): ApplyResult<Row> {
  const now = evaluationTime(options);
  if (q.grouping) {
    const grouped = prepareGrouping(rows, schema, q.grouping, { now });
    // Grouped results are projections described by grouped.schema; they do not
    // retain source-row accessors or identities.
    return applyQuery(grouped.rows, withoutGrouping(q), grouped.schema, { now }) as ApplyResult<Row>;
  }
  const byName = indexFields(schema);
  const resolveField = (name: string) => resolveFieldName(schema, name) ?? name;
  // Terms touching a computed column are dropped here (the formula engine
  // evaluates those separately; `byName` has no opinion on them anyway). An OR
  // group is all-or-nothing, so a single computed member drops the whole term.
  const whereTerms = q.where
    .filter((term) => !predicatesOf(term).some((c) => isComputedField(c.field) && !computedInputAllowed(schema, c.field, "filter")))
    .map((term) => prepareWhereTerm(term, resolveField, now));
  prepareDatetimePredicates(whereTerms, byName);
  const orderBy = q.orderBy
    .filter((term) => !isComputedField(term.field) || computedInputAllowed(schema, term.field, "sort"))
    .map((term) => ({ ...term, field: resolveField(term.field) }));

  let out = rows.filter((row) =>
    whereTerms.every((term) => matchesTerm(byName, row, term)),
  );
  const total = out.length;

  if (orderBy.length) {
    const terms = orderBy
      .map((t) => ({
        field: byName.get(t.field),
        dir: t.dir,
        nullsLast: (t.nulls ?? "last") === "last",
        extract: compileRegex(t.extract?.regex),
      }))
      .filter(
        (
          t,
        ): t is {
          field: FieldDef<Row>;
          dir: "asc" | "desc";
          nullsLast: boolean;
          extract: RegExp | null | undefined;
        } => t.field != null,
      );
    out = [...out].sort((a, b) => {
      for (const t of terms) {
        const av = extractSortValue(readFieldValue(t.field, a), t.extract);
        const bv = extractSortValue(readFieldValue(t.field, b), t.extract);
        const aNull = av == null;
        const bNull = bv == null;
        if (aNull || bNull) {
          if (aNull && bNull) continue;
          return (aNull ? 1 : -1) * (t.nullsLast ? 1 : -1);
        }
        const cmp = compare(av, bv);
        if (cmp !== 0) return t.dir === "asc" ? cmp : -cmp;
      }
      return 0;
    });
  }

  const start = q.offset > 0 ? q.offset : 0;
  const end = q.limit > 0 ? start + q.limit : out.length;
  return { rows: out.slice(start, end), total };
}

/** Explicit host bindings or approved evaluated accessors can participate in
 * local source stages. Ordinary unapproved computed controls stay disabled. */
export function computedInputAllowed(schema: FieldSchema, name: string, operation: "filter" | "sort"): boolean {
  const field = schema.fields.find(field => field.name === name);
  return !!field && (field.source.kind === "backend" && field[operation]?.enabled !== false || field[operation]?.enabled === true);
}

/** Does one row satisfy one clause? Exposed for the CellMenu preview + tests. */
export function matchesClause<Row>(
  row: Row,
  clause: WhereClause,
  schema: FieldSchema<Row>,
  options: QueryEvaluationOptions = {},
): boolean {
  const field = resolveFieldName(schema, clause.field) ?? clause.field;
  const byName = indexFields(schema);
  const prepared = prepareWhereClause(
    { ...clause, field },
    evaluationTime(options),
  );
  prepareDatetimePredicates([{ kind: "lit", predicate: prepared }], byName);
  return matchesWith(byName, row, prepared);
}

/** Client-side mirror of the backend GROUP BY (the executor for `clientRows`
 *  mode / the demo). Scope matches the server contract: the WHERE-filtered set
 *  only — ORDER BY / LIMIT / OFFSET are intentionally ignored, so a metric
 *  reflects every matching row, not the visible page. Must agree with
 *  backends/go's aggregate compile on op semantics. */
export function applyAggregations<Row>(
  rows: Row[],
  q: QueryState,
  schema: FieldSchema<Row>,
  options: MetricEvaluationOptions<Row> = {},
): AggregationResult {
  if (q.grouping) return evaluateMetrics(rows, q, schema, options);
  if (
    options.signal?.aborted ||
    q.where.some((t) =>
      predicatesOf(t).some(
        (p) => p.op === "matches_regex" || p.op === "not_matches_regex",
      ),
    )
  )
    return evaluateMetrics(rows, q, schema, options);
  const advanced = (q.aggregations ?? []).filter(
    (a) =>
      a.dateGrouping ||
      a.diagnostics?.length ||
      a.expression !== undefined ||
      a.expressionY !== undefined ||
      a.scope !== undefined ||
      a.distribution ||
      a.sort ||
      a.groupLimit !== undefined,
  );
  if (advanced.length) {
    // Partitioning must not hide invalid IDs/shapes or the query-wide card cap.
    if (
      (q.aggregations?.length ?? 0) > 20 ||
      normalizeQueryState(q).aggregations?.length !== q.aggregations?.length
    )
      return evaluateMetrics(rows, q, schema, options);
    const legacy = (q.aggregations ?? []).filter((a) => !advanced.includes(a));
    const results = [
      ...evaluateMetrics(
        rows,
        { ...q, aggregations: advanced },
        schema,
        options,
      ).metrics,
      ...(legacy.length
        ? applyAggregations(
            rows,
            { ...q, aggregations: legacy },
            schema,
            options,
          ).metrics
        : []),
    ];
    const byId = new Map(results.map((result) => [result.id, result]));
    return {
      metrics: (q.aggregations ?? []).flatMap((a) => byId.get(a.id) ?? []),
    };
  }
  const now = evaluationTime(options);
  const byName = indexFields(schema);
  const resolveField = (name: string) => resolveFieldName(schema, name) ?? name;
  const whereTerms = q.where
    .filter((term) => !predicatesOf(term).some((c) => isComputedField(c.field)))
    .map((term) => prepareWhereTerm(term, resolveField, now));
  prepareDatetimePredicates(whereTerms, byName);
  const filtered = rows.filter((row) =>
    whereTerms.every((term) => matchesTerm(byName, row, term)),
  );
  const metrics = (q.aggregations ?? [])
    .filter(
      (a) =>
        !isComputedField(a.field ?? "") && !a.groupBy.some(isComputedField),
    )
    .map((agg) => {
      const field = agg.field ? byName.get(resolveField(agg.field)) : undefined;
      if (
        field &&
        (!isMeasurable(field) || !aggOpsForField(field).includes(agg.op))
      )
        return {
          id: agg.id,
          buckets: [],
          error: `Field ${field.name} does not allow ${agg.op}.`,
        };
      return {
        id: agg.id,
        buckets: computeBuckets(filtered, agg, byName, resolveField),
      };
    });
  return { metrics };
}

function computeBuckets<Row>(
  rows: Row[],
  agg: AggregationClause,
  byName: Map<string, FieldDef<Row>>,
  resolveField: (field: string) => string,
): AggregationBucket[] {
  // One slot per groupBy entry, preserving position. An unresolved field stays
  // in the array as `undefined` so every bucket's `keys` has exactly one element
  // per requested group field — the panel renders keys positionally against
  // `clause.groupBy`, so dropping an entry here would shift every later column.
  const groupFields = agg.groupBy.map((n) => byName.get(resolveField(n)));
  const measure = agg.field ? byName.get(resolveField(agg.field)) : undefined;

  const groups = new Map<string, { keys: MetricKey[]; rows: Row[] }>();
  if (!agg.groupBy.length) groups.set("[]", { keys: [], rows: [] });
  for (const row of rows) {
    const keys = groupFields.map((f) => {
      if (!f) return null; // unresolved group field → NULL bucket, never a missing column
      const v = readFieldValue(f, row);
      return v == null || v === ""
        ? null
        : typeof v === "number" ||
            typeof v === "boolean" ||
            typeof v === "string"
          ? v
          : String(v);
    });
    const k = JSON.stringify(keys);
    let g = groups.get(k);
    if (!g) {
      g = { keys, rows: [] };
      groups.set(k, g);
    }
    g.rows.push(row);
  }

  const buckets = [...groups.values()].map((g) => ({
    keys: g.keys,
    count: g.rows.length,
    value: aggValue(agg.op, measure, g.rows),
  }));
  return sortBuckets(buckets);
}

function aggValue<Row>(
  op: AggOp,
  measure: FieldDef<Row> | undefined,
  rows: Row[],
): number | string | null {
  if (op === "count") {
    if (!measure) return rows.length; // COUNT(*)
    let n = 0;
    for (const r of rows) if (readFieldValue(measure, r) != null) n++; // COUNT(expr) = non-null
    return n;
  }
  if (!measure) return null;
  const values = rows
    .map((r) => readFieldValue(measure, r))
    .filter((v) => v != null);

  switch (op) {
    case "count_distinct":
      return new Set(values.map((v) => String(v))).size;
    case "sum":
    case "avg": {
      let sum = 0;
      let n = 0;
      for (const v of values) {
        const num = typeof v === "number" ? v : Number(v);
        if (Number.isFinite(num)) {
          sum += num;
          n++;
        }
      }
      if (op === "avg") return n ? sum / n : null;
      return n ? sum : null;
    }
    case "min":
    case "max": {
      let best: unknown;
      for (const v of values) {
        if (best === undefined) {
          best = v;
          continue;
        }
        const cmp = compare(v, best);
        if (op === "min" ? cmp < 0 : cmp > 0) best = v;
      }
      return (best as number | string | undefined) ?? null;
    }
    default:
      return null;
  }
}

/** Stable display order: descending by the metric (or group size when the metric
 *  isn't numeric), then by group key. The 2D pivot ignores this; the 1D bar list
 *  and the flat N-column table read top-to-bottom from it. */
function sortBuckets(buckets: AggregationBucket[]): AggregationBucket[] {
  return [...buckets].sort((a, b) => {
    const av = typeof a.value === "number" ? a.value : a.count;
    const bv = typeof b.value === "number" ? b.value : b.count;
    if (av !== bv) return bv - av;
    return JSON.stringify(a.keys).localeCompare(JSON.stringify(b.keys));
  });
}

interface PreparedWhereClause {
  clause: WhereClause;
  now: number;
  datetime?: number;
  regex: RegExp | null | undefined;
}

type PreparedWhereTerm =
  | { kind: "lit"; predicate: PreparedWhereClause }
  | { kind: "or"; predicates: PreparedWhereClause[] };

function prepareWhereClause(
  clause: WhereClause,
  now: number,
): PreparedWhereClause {
  const usesRegex =
    clause.op === "matches_regex" || clause.op === "not_matches_regex";
  return {
    clause,
    now,
    regex: usesRegex ? compileRegex(clause.value) : undefined,
  };
}

function prepareWhereTerm(
  term: WhereTerm,
  resolveField: (name: string) => string,
  now: number,
): PreparedWhereTerm {
  if (isOrGroup(term)) {
    return {
      kind: "or",
      predicates: term.any.map((c) =>
        prepareWhereClause({ ...c, field: resolveField(c.field) }, now),
      ),
    };
  }
  return {
    kind: "lit",
    predicate: prepareWhereClause(
      { ...term, field: resolveField(term.field) },
      now,
    ),
  };
}

function prepareDatetimePredicates<Row>(
  terms: PreparedWhereTerm[],
  fields: Map<string, FieldDef<Row>>,
): void {
  for (const term of terms)
    for (const p of term.kind === "lit" ? [term.predicate] : term.predicates) {
      const field = fields.get(p.clause.field);
      if (
        field?.type !== "datetime" ||
        p.clause.value === "" ||
        p.clause.op === "is_null" ||
        p.clause.op === "is_not_null"
      )
        continue;
      p.datetime = coerceValue("datetime", p.clause.value, p.now) as number;
    }
}

/** A row satisfies the WHERE when every term matches (AND); a term matches when
 *  its sole predicate matches, or — for an OR group — when any member does. */
function matchesTerm<Row>(
  byName: Map<string, FieldDef<Row>>,
  row: Row,
  term: PreparedWhereTerm,
): boolean {
  if (term.kind === "lit") return matchesWith(byName, row, term.predicate);
  // Normalization never yields an empty group (0 dropped, 1 flattened), so
  // `some` over a non-empty list is the OR.
  return term.predicates.some((p) => matchesWith(byName, row, p));
}

function matchesWith<Row>(
  byName: Map<string, FieldDef<Row>>,
  row: Row,
  prepared: PreparedWhereClause,
): boolean {
  const { clause } = prepared;
  const field = byName.get(clause.field);
  if (!field) return true; // unknown field → no client opinion
  const v = readFieldValue(field, row);

  // Empty value on a non-equality, value-taking op is a "no filter" signal —
  // true for BOTH the predicate and its negation (matches the UI + the Go
  // compiler, which skip such clauses). Nullary ops legitimately use value "".
  if (
    clause.value === "" &&
    clause.op !== "=" &&
    clause.op !== "!=" &&
    clause.op !== "is_null" &&
    clause.op !== "is_not_null"
  ) {
    return true;
  }

  if (
    clause.op === "length_gt" ||
    clause.op === "length_lt" ||
    clause.op === "length_eq"
  ) {
    if (
      !/^(0|[1-9]\d*)$/.test(clause.value) ||
      !Number.isSafeInteger(Number(clause.value))
    )
      return false;
  }

  let base: boolean;
  if (prepared.datetime !== undefined) {
    const timestamp =
      v instanceof Date
        ? v.getTime()
        : typeof v === "number"
          ? v
          : typeof v === "string"
            ? Date.parse(v)
            : NaN;
    if (v === "" || !Number.isFinite(timestamp)) return false;
    base = matchesDatetime(timestamp, prepared.datetime, clause.op);
  } else {
    base = matchesBase(field, v, prepared);
  }
  if (!clause.negated) return base;
  // Null-exclusive NOT: a NULL/empty value satisfies neither the predicate nor
  // its negation (mirrors `not_matches_regex` and the server's trailing
  // `AND <expr> IS NOT NULL`).
  const isNull = Array.isArray(v) ? v.length === 0 : v == null || v === "";
  return !isNull && !base;
}

function matchesDatetime(
  timestamp: number,
  rhs: number,
  op: WhereClause["op"],
): boolean {
  switch (op) {
    case "=":
      return timestamp === rhs;
    case "!=":
      return timestamp !== rhs;
    case ">":
      return timestamp > rhs;
    case ">=":
      return timestamp >= rhs;
    case "<":
      return timestamp < rhs;
    case "<=":
      return timestamp <= rhs;
    default:
      return false;
  }
}

/** The bare predicate result, ignoring `negated` and the empty-value skip
 *  (both handled by `matchesWith`). */
function matchesBase<Row>(
  field: FieldDef<Row>,
  v: unknown,
  prepared: PreparedWhereClause,
): boolean {
  const { clause, regex } = prepared;

  // Nullity, with array-aware semantics.
  if (clause.op === "is_null")
    return Array.isArray(v) ? v.length === 0 : v == null || v === "";
  if (clause.op === "is_not_null")
    return Array.isArray(v) ? v.length > 0 : v != null && v !== "";

  const arrayText = (value: unknown) =>
    field.filter?.arrayCaseSensitive
      ? String(value)
      : String(value).toLowerCase();

  // `includes` is array membership (ARRAY_HAS): a null/missing array contains
  // nothing. Handle before the array/scalar split so null can't fall through.
  if (clause.op === "includes") {
    const arr = Array.isArray(v) ? v : [];
    const needle = arrayText(clause.value);
    return arr.some((x) => arrayText(x) === needle);
  }

  if (clause.op === "matches_regex" || clause.op === "not_matches_regex") {
    if (v == null || Array.isArray(v)) return false;
    if (!regex) return false;
    const matches = regex.test(String(v));
    return clause.op === "matches_regex" ? matches : !matches;
  }

  if (
    clause.op === "length_gt" ||
    clause.op === "length_lt" ||
    clause.op === "length_eq"
  ) {
    if (typeof v !== "string" || !/^(0|[1-9]\d*)$/.test(clause.value))
      return false;
    const limit = Number(clause.value);
    if (!Number.isSafeInteger(limit)) return false;
    const length = Array.from(v).length;
    return clause.op === "length_gt"
      ? length > limit
      : clause.op === "length_lt"
        ? length < limit
        : length === limit;
  }

  if (Array.isArray(v)) {
    const needle = arrayText(clause.value);
    const hay = v.map(arrayText);
    switch (clause.op) {
      case "contains":
        return hay.some((s) => s.includes(needle));
      case "=":
        return hay.includes(needle);
      case "!=":
        return !hay.includes(needle);
      default:
        return true;
    }
  }

  switch (clause.op) {
    case "=":
      return String(v ?? "") === String(coerceSafe(field, clause.value));
    case "!=":
      return String(v ?? "") !== String(coerceSafe(field, clause.value));
    case ">":
      return compare(v, coerceSafe(field, clause.value)) > 0;
    case ">=":
      return compare(v, coerceSafe(field, clause.value)) >= 0;
    case "<":
      return compare(v, coerceSafe(field, clause.value)) < 0;
    case "<=":
      return compare(v, coerceSafe(field, clause.value)) <= 0;
    case "contains":
      return String(v ?? "")
        .toLowerCase()
        .includes(clause.value.toLowerCase());
    case "starts_with":
      return String(v ?? "")
        .toLowerCase()
        .startsWith(clause.value.toLowerCase());
    case "ends_with":
      return String(v ?? "")
        .toLowerCase()
        .endsWith(clause.value.toLowerCase());
    default:
      return true;
  }
}

/** `null` means an invalid pattern; `undefined` means no regex was requested. */
function compileRegex(pattern: string | undefined): RegExp | null | undefined {
  if (pattern === undefined) return undefined;
  try {
    return new RegExp(pattern);
  } catch {
    return null;
  }
}

function extractSortValue(
  value: unknown,
  regex: RegExp | null | undefined,
): unknown {
  if (regex === undefined) return value;
  if (regex === null || value == null) return null;
  const match = regex.exec(String(value));
  if (!match) return null;
  return match.length > 1 ? (match[1] ?? null) : match[0];
}

/** Coerce per the field type, falling back to the raw string if coercion fails
 *  (so a malformed value degrades to a string compare rather than throwing). */
function coerceSafe(field: FieldDef, raw: string): string | number | boolean {
  try {
    return coerceValue(field.type, raw);
  } catch {
    return raw;
  }
}

function compare(a: unknown, b: unknown): number {
  if (a == null && b == null) return 0;
  if (a == null) return -1;
  if (b == null) return 1;
  if (typeof a === "number" && typeof b === "number") return a - b;
  if (typeof a === "boolean" && typeof b === "boolean")
    return a === b ? 0 : a ? 1 : -1;
  return String(a).localeCompare(String(b));
}
