import { describe, it, expect } from "vitest";
import {
  loadSchema,
  selectedFields,
  readFieldValue,
  isFilterable,
  isPushdownFilter,
  isSortable,
  isSelectable,
  opsForField,
  OPS_BY_TYPE,
} from "../src/index";
import { runsSchema, rows } from "./fixtures";

describe("per-source capability defaults", () => {
  const f = (name: string) => runsSchema.fields.find((x) => x.name === name)!;

  it("backend fields filter/sort by default; derived do not", () => {
    expect(isFilterable(f("overall"))).toBe(true);
    expect(isSortable(f("overall"))).toBe(true);
    expect(isFilterable(f("details"))).toBe(false); // derived
    expect(isSortable(f("details"))).toBe(false);
  });

  it("pushdown:false keeps the field filterable but client-side", () => {
    expect(isFilterable(f("error_codes"))).toBe(true);
    expect(isPushdownFilter(f("error_codes"))).toBe(false);
  });

  it("selectable defaults true", () => {
    expect(isSelectable(f("id"))).toBe(true);
  });
});

describe("ops matrix — nullity on every type, incl. bool", () => {
  it.each(["text", "number", "enum", "datetime", "bool", "textarray"] as const)("%s allows is_null/is_not_null", (t) => {
    expect(OPS_BY_TYPE[t]).toContain("is_null");
    expect(OPS_BY_TYPE[t]).toContain("is_not_null");
  });

  it("field op override wins", () => {
    expect(opsForField({ type: "text", filter: { ops: ["="] } })).toEqual(["="]);
  });

  it("offers positive and negative regex matching for text", () => {
    expect(OPS_BY_TYPE.text).toContain("matches_regex");
    expect(OPS_BY_TYPE.text).toContain("not_matches_regex");
    expect(OPS_BY_TYPE.text).toContain("length_gt");
    expect(OPS_BY_TYPE.text).toContain("length_lt");
    expect(OPS_BY_TYPE.text).toContain("length_eq");
    expect(OPS_BY_TYPE.enum).not.toContain("matches_regex");
    expect(OPS_BY_TYPE.enum).not.toContain("length_gt");
  });
});

describe("selectedFields", () => {
  it("uses defaults when query.select is empty", () => {
    expect(selectedFields(runsSchema, { select: [] }).map((f) => f.name)).toEqual(["case_name", "overall", "total_ms"]);
  });
  it("honors explicit order and drops unknown/unselectable", () => {
    const got = selectedFields(runsSchema, {
      select: [{ field: "overall" }, { field: "nope" }, { field: "case_name" }],
    });
    expect(got.map((f) => f.name)).toEqual(["overall", "case_name"]);
  });
});

describe("readFieldValue", () => {
  it("reads a backend column by name", () => {
    expect(readFieldValue(runsSchema.fields.find((f) => f.name === "case_name")!, rows[1]!)).toBe("bravo");
  });
});

describe("loadSchema", () => {
  it("rejects invalid object presentation and relationship metadata", () => {
    const document = { name: "x", idField: "id", fields: [{ name: "id", label: "ID", type: "text" }] };
    for (const metadata of [
      { property: false }, { property: { enabled: "no" } },
      { property: { format: { kind: "unknown" } } },
      { origin: { table: "x" } },
      { relationship: { objectType: "x", key: {} } },
    ]) {
      expect(() => loadSchema({ ...document, fields: [{ ...document.fields[0], ...metadata }] })).toThrow(/schema: field id/);
    }
  });
  it("projects a JSON doc and infers source from bindings", () => {
    const doc = {
      name: "wb",
      idField: "id",
      fields: [
        { name: "id", label: "ID", type: "number", bindings: { postgres: { expr: "w.id" } } },
        { name: "details", label: "D", type: "text", source: "derived", render: "detail_link" },
      ],
    };
    const s = loadSchema(doc);
    expect(s.fields[0]!.source.kind).toBe("backend"); // inferred from bindings
    expect(s.fields[1]!.source.kind).toBe("derived");
    expect(s.fields[1]!.render).toBe("detail_link");
  });

  it("throws a readable error on a malformed doc", () => {
    expect(() => loadSchema({ name: "x" })).toThrow(/idField/);
  });
});

describe("declarative display schema", () => {
  const doc = (display: unknown) => ({ name: "values", idField: "value", fields: [{ name: "value", label: "Value", type: "text", source: "backend", display }] });
  it("preserves display settings independently of query type and capabilities", () => {
    const display = { kind: "json", encoding: "escaped", maxDecodeDepth: 6, previewLength: 100 };
    const field = loadSchema(doc(display)).fields[0]!;
    expect(field.display).toEqual(display);
    expect(field.type).toBe("text");
    expect(isFilterable(field)).toBe(true);
  });
  it.each([
    { kind: "json", maxDecodeDepth: 20 }, { kind: "json", encoding: "loose" },
    { kind: "duration", sourceUnit: "iso" }, { kind: "number", decimals: -1 },
    { kind: "date", sourceUnit: "secondsOfDay" }, { kind: "chip", tones: { ok: "green" } },
    { kind: "text", truncate: "yes" }, { kind: "unknown" }, { kind: "json", unexpected: true }, null,
  ])("rejects malformed display config: %j", (display) => {
    expect(() => loadSchema(doc(display))).toThrow("field value display");
  });
});
