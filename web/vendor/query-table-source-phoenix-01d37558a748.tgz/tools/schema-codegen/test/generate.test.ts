import Ajv2020 from "ajv/dist/2020";
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { generateGo, generateTypeScript } from "../src/index";

const documentPath = fileURLToPath(
  new URL("../../../schema/examples/runs.schema.json", import.meta.url),
);
const document = JSON.parse(readFileSync(documentPath, "utf8"));

describe("schema code generation", () => {
  it("validates and preserves object property and relationship metadata", () => {
    const configured = structuredClone(document);
    const field = configured.fields[0];
    field.property = { default: true, format: { kind: "currency", currency: "USD", decimals: 4 } };
    field.origin = { table: "runs", column: "id" };
    field.relationship = { objectType: "runs", key: { id: "id" } };
    const metaSchema = JSON.parse(readFileSync(new URL("../../../schema/query-table.schema.json", import.meta.url), "utf8"));
    const validate = new Ajv2020({ strict: false }).compile(metaSchema);
    expect(validate(configured), JSON.stringify(validate.errors)).toBe(true);
    const generated = generateTypeScript(configured);
    expect(generated).toContain('"currency": "USD"');
    expect(generated).toContain('"table": "runs"');
    expect(generated).toContain('"objectType": "runs"');
    expect(generated).not.toContain('"bindings"');
    delete field.property.format.currency;
    expect(validate(configured)).toBe(false);
    expect(() => generateTypeScript(configured)).toThrow("invalid property format");
  });
  it("generates a frontend schema without backend SQL bindings", () => {
    const output = generateTypeScript(document);
    expect(output).toContain("export const RUNS_SCHEMA: FieldSchema");
    expect(output).toContain('"job_name"');
    expect(output).not.toContain("bindings");
    expect(output).not.toContain("r.job_name");
  });

  it("generates a direct Go schema with backend capabilities", () => {
    const withRegexSort = structuredClone(document);
    withRegexSort.defaultSort = [
      { field: "job_name", dir: "asc", extract: { regex: "build-(\\d+)" } },
    ];
    withRegexSort.fields.find(
      (field: { name: string }) => field.name === "job_name",
    ).filter = { ops: ["="], arrayCaseSensitive: true };
    const output = generateGo(withRegexSort, { packageName: "catalog" });
    expect(output).toContain("func RunsSchema() querytable.Schema");
    expect(output).toContain('"error_codes": {');
    expect(output).toContain("ServerFilter: false");
    expect(output).toContain("Synthetic: true");
    expect(output).toContain("ArrayCaseSensitive: true");
    expect(output).toContain('FilterOps: []string{"="}');
    expect(output).toContain(
      'Extract: &querytable.RegexExtract{Regex: "build-(\\\\d+)"}',
    );
    expect(output).not.toContain('"details": {');

    const formatted = spawnSync("gofmt", { input: output, encoding: "utf8" });
    expect(formatted.error).toBeUndefined();
    expect(formatted.status).toBe(0);
    expect(formatted.stdout).toBe(output);
  });

  it("generates SQLite bindings without using Postgres expressions", () => {
    const configured = structuredClone(document);
    for (const field of configured.fields) {
      if (!field.bindings?.postgres) continue;
      field.bindings.sqlite = { expr: `s.${field.name}` };
      if (field.type === "datetime") field.bindings.sqlite.datetimeFormat = "utc-millis";
      if (field.type === "number") field.bindings.sqlite.expressionNumeric = true;
    }
    configured.fields.find((f: { name: string }) => f.name === "job_name").sort = { field: "enqueued_at" };
    const metaSchema = JSON.parse(readFileSync(new URL("../../../schema/query-table.schema.json", import.meta.url), "utf8"));
    const validate = new Ajv2020({ strict: false }).compile(metaSchema);
    expect(validate(configured), JSON.stringify(validate.errors)).toBe(true);
    const output = generateGo(configured, { packageName: "catalog", dialect: "sqlite" });
    expect(output).toContain('Expr: "s.id"');
    expect(output).toContain('SQLiteDatetimeFormat: "utc-millis"');
    expect(output).toContain('SQLiteSortField: "enqueued_at"');
    expect(output).toContain("ExpressionNumeric: true");
    expect(output).not.toContain('Expr: "r.id"');
    const formatted = spawnSync("gofmt", { input: output, encoding: "utf8" });
    expect(formatted.status).toBe(0);
    expect(formatted.stdout).toBe(output);
    delete configured.fields.find((f: { name: string }) => f.name === "id").bindings.sqlite;
    expect(() => generateGo(configured, { packageName: "catalog", dialect: "sqlite" })).toThrow(/id field .* has no sqlite binding/);
  });

  it("preserves metric policy and trusted numeric expression bindings", () => {
    const configured = structuredClone(document);
    const numeric = configured.fields.find(
      (field: { name: string }) => field.name === "total_ms",
    );
    numeric.bindings.postgres.expressionNumeric = true;
    numeric.aggregate = { groupable: true, ops: ["avg", "max"] };
    configured.fields.find(
      (field: { name: string }) => field.name === "platform",
    ).aggregate = { measure: false, groupable: false };
    const metaSchema = JSON.parse(
      readFileSync(
        new URL("../../../schema/query-table.schema.json", import.meta.url),
        "utf8",
      ),
    );
    const validate = new Ajv2020({ strict: false }).compile(metaSchema);
    expect(validate(configured), JSON.stringify(validate.errors)).toBe(true);
    numeric.bindings.postgres.expressionNumeric = "untrusted";
    expect(validate(configured)).toBe(false);
    numeric.bindings.postgres.expressionNumeric = true;
    const output = generateGo(configured, { packageName: "catalog" });
    expect(output).toContain("ExpressionNumeric: true");
    expect(output).toContain('AggregateOps: []string{"avg", "max"}');
    expect(output).toContain("AggregateOps: []string{}");
    expect(output).toContain(
      "Groupable: func() *bool { v := true; return &v }()",
    );
    expect(output).toContain(
      "Groupable: func() *bool { v := false; return &v }()",
    );
    const formatted = spawnSync("gofmt", { input: output, encoding: "utf8" });
    expect(formatted.status).toBe(0);
    expect(formatted.stdout).toBe(output);
    expect(generateTypeScript(configured)).not.toContain("expressionNumeric");
  });

  it("rejects invalid Go package names", () => {
    expect(() => generateGo(document, { packageName: "bad-name" })).toThrow(
      /invalid Go package name/,
    );
    expect(() => generateGo(document, { packageName: "package" })).toThrow(
      /invalid Go package name/,
    );
  });

  it("rejects backend references that cannot produce a valid Go schema", () => {
    const missingIdBinding = structuredClone(document);
    delete missingIdBinding.fields.find(
      (field: { name: string }) => field.name === missingIdBinding.idField,
    ).bindings;
    expect(() =>
      generateGo(missingIdBinding, { packageName: "catalog" }),
    ).toThrow(/id field .* has no postgres binding/);

    const missingSortBinding = structuredClone(document);
    missingSortBinding.fields.find(
      (field: { name: string }) => field.name === "job_name",
    ).sort = { field: "details" };
    expect(() =>
      generateGo(missingSortBinding, { packageName: "catalog" }),
    ).toThrow(/sort target .* has no postgres binding/);
    expect(() =>
      generateGo(document, { packageName: "catalog", importPath: "bad\npath" }),
    ).toThrow(/invalid Go import path/);
  });
});

describe("cell display contract", () => {
  const metaSchema = JSON.parse(readFileSync(new URL("../../../schema/query-table.schema.json", import.meta.url), "utf8"));
  const validate = new Ajv2020({ strict: false }).compile(metaSchema);
  const doc = (display: unknown) => ({ name: "values", idField: "value", fields: [{ name: "value", label: "Value", type: "text", source: "backend", display, bindings: { postgres: { expr: "v.value" } } }] });
  it.each([
    { kind: "json", encoding: "escaped", expandDepth: 2 },
    { kind: "datetime", sourceUnit: "epochSeconds", timeZone: "UTC" },
    { kind: "time", sourceUnit: "secondsOfDay", style: "iso" },
    { kind: "duration", sourceUnit: "seconds", style: "clock" },
    { kind: "chip", labels: { ok: "Ready" }, tones: { ok: "success" } },
    { kind: "number", decimals: 3, locale: "en-US" }, { kind: "text", truncate: true },
  ])("validates and preserves frontend config %j without changing SQL", (display) => {
    expect(validate(doc(display)), JSON.stringify(validate.errors)).toBe(true);
    expect(generateTypeScript(doc(display))).toContain(JSON.stringify(display.kind));
    expect(generateTypeScript(doc(display))).toContain('"display"');
    expect(generateGo(doc(display), { packageName: "catalog" })).not.toContain("display");
  });
  it.each([{ kind: "json", expandDepth: 10 }, { kind: "time", sourceUnit: "days" }, { kind: "chip", tones: { ok: "green" } }, { kind: "duration", unexpected: true }])("rejects invalid schema config %j", (display) => {
    expect(validate(doc(display))).toBe(false);
  });
});

describe("detail JSON display configuration", () => {
  it("validates and projects the same JSON settings in display and property formats", () => {
    const display = { kind: "json", encoding: "escaped", maxDecodeDepth: 5, expandDepth: 2 };
    const configured = structuredClone(document);
    configured.fields[0].display = display;
    configured.fields[0].property = { format: display };
    const metaSchema = JSON.parse(readFileSync(new URL("../../../schema/query-table.schema.json", import.meta.url), "utf8"));
    const validate = new Ajv2020({ strict: false }).compile(metaSchema);
    expect(validate(configured), JSON.stringify(validate.errors)).toBe(true);
    const output = generateTypeScript(configured);
    expect(output).toContain('"encoding": "escaped"');
    expect(output).toContain('"property"');
    configured.fields[0].property.format.maxDecodeDepth = 99;
    expect(validate(configured)).toBe(false);
  });
});
