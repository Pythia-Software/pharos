import { Icon } from "@pythia-software/query-table-ui";
import { useId, type ReactNode } from "react";

export interface CollapsibleSectionProps {
  title: string;
  collapsed: boolean;
  onToggle: (nextCollapsed: boolean) => void;
  collapsedSummary?: ReactNode;
  children: ReactNode;
  className?: string;
}

const cx = (...parts: Array<string | undefined>): string => parts.filter(Boolean).join(" ");

export function CollapsibleSection({
  title,
  collapsed,
  onToggle,
  collapsedSummary,
  children,
  className,
}: CollapsibleSectionProps): ReactNode {
  const bodyId = useId();
  const hasSummary = collapsedSummary != null;

  return (
    <section className={cx("qt-qt-section", collapsed ? "qt-qt-section--collapsed" : "qt-qt-section--expanded", className)}>
      <div className="qt-qt-section-head">
        <button
          type="button"
          className="qt-btn qt-qt-section-toggle"
          onClick={() => onToggle(!collapsed)}
          aria-expanded={!collapsed}
          aria-controls={bodyId}
          aria-label={collapsed ? `Expand ${title}` : `Collapse ${title}`}
          title={collapsed ? `Expand ${title}` : `Collapse ${title}`}
        >
          <Icon name="chevronDown" size={18} className={collapsed ? "qt-qt-section-toggle-caret qt-qt-section-toggle-caret--collapsed" : "qt-qt-section-toggle-caret"} />
          <span className="qt-qt-section-title">{title}</span>
        </button>
        {hasSummary ? <span className="qt-qt-section-summary">{collapsedSummary}</span> : null}
      </div>
      {!collapsed ? <div id={bodyId}>{children}</div> : null}
    </section>
  );
}
